package LowLevelDesign.DesignBookMyShow;

public class Payment {

    int paymentId;
    //Other payment details
}
