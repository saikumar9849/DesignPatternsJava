package LowLevelDesign.DesignPatterns.FlyWeightPattern;

public class Sprites {
}
