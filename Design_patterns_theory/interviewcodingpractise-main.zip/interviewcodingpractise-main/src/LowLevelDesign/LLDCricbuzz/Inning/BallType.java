package LowLevelDesign.LLDCricbuzz.Inning;

public enum BallType {

    NORMAL,
    WIDEBALL,
    NOBALL;
}
