package LowLevelDesign.HandleNullObject;

public interface Vehicle {

    int getTankCapacity();
    int getSeatingCapacity();
}
