package LowLevelDesign.DesignOrderManagementSystem;

public class UPIPaymentMode implements PaymentMode{

    @Override
    public boolean makePayment() {
        return true;
    }
}
