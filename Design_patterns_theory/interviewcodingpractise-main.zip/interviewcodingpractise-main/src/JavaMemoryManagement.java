public class JavaMemoryManagement {
    //https://www.youtube.com/watch?v=450maTzSIvA

    //stack and heap memory management tutorial
}
